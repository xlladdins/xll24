// template.cpp
#include "xll.h"